package com.xiaobulocklaunch;

import org.json.JSONException;
import org.json.JSONObject;

public final class Rule {
    public static final String MODE_APP = "B";
    public static final String MODE_CUSTOM = "C";

    public String mode;
    public String aliases;
    public String packageName;
    public String appLabel;
    public boolean enabled = true;

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("mode", mode);
        o.put("aliases", aliases);
        o.put("packageName", packageName);
        o.put("appLabel", appLabel);
        o.put("enabled", enabled);
        return o;
    }

    public static Rule fromJson(JSONObject o) {
        Rule r = new Rule();
        r.mode = o.optString("mode", MODE_APP);
        r.aliases = o.optString("aliases", "");
        r.packageName = o.optString("packageName", "");
        r.appLabel = o.optString("appLabel", r.packageName);
        r.enabled = o.optBoolean("enabled", true);
        return r;
    }
}
