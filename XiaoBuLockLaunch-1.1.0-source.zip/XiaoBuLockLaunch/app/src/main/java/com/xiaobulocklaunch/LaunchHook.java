package com.xiaobulocklaunch;

import android.app.AndroidAppHelper;
import android.app.KeyguardManager;
import android.content.Context;
import android.os.Bundle;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class LaunchHook implements IXposedHookLoadPackage {
    private static final String TARGET = "com.heytap.speechassist";
    private static final String OPERATION = "com.heytap.speechassist.skill.openapp.operation.OpenAppOperation";
    private static final String LAUNCH_APP = "com.heytap.speech.engine.protocol.directive.app.LaunchApp";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET.equals(lpparam.packageName)) return;
        try {
            Class<?> launchAppClass = XposedHelpers.findClass(LAUNCH_APP, lpparam.classLoader);
            Class<?> operationClass = XposedHelpers.findClass(OPERATION, lpparam.classLoader);
            XposedHelpers.findAndHookMethod(operationClass, "tryLaunchApp", launchAppClass, new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam param) {
                    try {
                        Object directive = param.args[0];
                        if (directive == null) return;
                        Context context = AndroidAppHelper.currentApplication();
                        if (context == null) return;

                        String sourceName = (String) XposedHelpers.callMethod(directive, "getAppName");
                        String sourcePackage = (String) XposedHelpers.callMethod(directive, "getPackageName");
                        Config config = readConfig(context);
                        if (config == null || !config.enableMaster || config.rules.isEmpty()) return;

                        boolean locked = false;
                        Object service = context.getSystemService(Context.KEYGUARD_SERVICE);
                        if (service instanceof KeyguardManager) locked = ((KeyguardManager) service).isKeyguardLocked();
                        if (locked && !config.allowLockedMapping) return;

                        RuleMatch match = findMatch(config, sourceName, sourcePackage);
                        if (match == null) return;
                        if (locked) XposedBridge.log("[XiaoBuLockLaunch] matched while keyguard locked; native XiaoBu/system keyguard policy remains in control");

                        XposedHelpers.callMethod(directive, "setPackageName", match.packageName);
                        if (match.appLabel != null && !match.appLabel.isEmpty()) {
                            XposedHelpers.callMethod(directive, "setAppName", match.appLabel);
                        }
                        XposedBridge.log("[XiaoBuLockLaunch] remap: " + sourceName + " [" + sourcePackage + "] -> " + match.appLabel + " [" + match.packageName + "] mode=" + match.mode);
                    } catch (Throwable t) {
                        XposedBridge.log("[XiaoBuLockLaunch] hook error: " + t);
                    }
                }
            });
            XposedBridge.log("[XiaoBuLockLaunch] hooked OpenAppOperation.tryLaunchApp for " + lpparam.packageName);
        } catch (Throwable t) {
            XposedBridge.log("[XiaoBuLockLaunch] hook install failed: " + t);
        }
    }

    private static Config readConfig(Context context) {
        try {
            Bundle b = context.getContentResolver().call(RulesProvider.URI, "get_config", null, null);
            if (b == null) return null;
            Config c = new Config();
            c.enableMaster = b.getBoolean("enable_master", true);
            c.enableB = b.getBoolean("enable_b", true);
            c.enableC = b.getBoolean("enable_c", true);
            c.allowLockedMapping = b.getBoolean("allow_locked_mapping", true);
            JSONArray a = new JSONArray(b.getString("rules_json", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                Rule r = Rule.fromJson(o);
                if (r.enabled && r.packageName != null && !r.packageName.isEmpty()) c.rules.add(r);
            }
            return c;
        } catch (Throwable t) {
            XposedBridge.log("[XiaoBuLockLaunch] config provider unavailable: " + t);
            return null;
        }
    }

    private static RuleMatch findMatch(Config config, String sourceName, String sourcePackage) {
        String n = normalize(sourceName);
        String p = normalize(sourcePackage);
        // C rules are checked first so a custom phrase wins over a general app alias.
        for (String mode : new String[]{Rule.MODE_CUSTOM, Rule.MODE_APP}) {
            if (Rule.MODE_CUSTOM.equals(mode) && !config.enableC) continue;
            if (Rule.MODE_APP.equals(mode) && !config.enableB) continue;
            for (Rule r : config.rules) {
                if (!mode.equalsIgnoreCase(r.mode)) continue;
                for (String alias : r.aliases.split("[,，;；\\n]")) {
                    String a = normalize(alias);
                    if (a.isEmpty()) continue;
                    if (a.equals(n) || a.equals(p)) return new RuleMatch(r);
                }
            }
        }
        return null;
    }

    private static String normalize(String value) {
        if (value == null) return "";
        String s = value.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", "");
        s = s.replace("，", "").replace(",", "").replace("。", "").replace("！", "").replace("!", "");
        String[] prefixes = {"请帮我打开", "帮我打开", "打开一下", "请打开", "启动一下", "打开", "启动"};
        for (String prefix : prefixes) if (s.startsWith(prefix)) { s = s.substring(prefix.length()); break; }
        return s;
    }

    private static final class Config {
        boolean enableMaster, enableB, enableC, allowLockedMapping;
        final List<Rule> rules = new ArrayList<>();
    }
    private static final class RuleMatch {
        final String mode, packageName, appLabel;
        RuleMatch(Rule r) { mode = r.mode; packageName = r.packageName; appLabel = r.appLabel; }
    }
}
