package com.xiaobulocklaunch;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public final class MainActivity extends Activity {
    public static final String PREFS = "xiaobu_lock_launch";
    public static final String KEY_RULES = "rules_json";
    public static final String KEY_ENABLE_B = "enable_b";
    public static final String KEY_ENABLE_C = "enable_c";
    public static final String KEY_ALLOW_LOCKED = "allow_locked_mapping";
    public static final String KEY_ENABLE_MASTER = "enable_master";

    private SharedPreferences prefs;
    private LinearLayout root, rulesBox;
    private CheckBox enableMaster, enableB, enableC, allowLocked;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildUi();
        refreshRules();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18), dp(20), dp(18), dp(24));
        scroll.addView(root); setContentView(scroll);

        TextView title = text("小布锁屏启动", 26, true); root.addView(title);
        TextView subtitle = text("一加 13 · ColorOS 17 · 小布助手 13.4.3", 14, false); subtitle.setTextColor(0xff667085); root.addView(subtitle);
        addGap(root, 16);

        TextView status = text("工作方式", 18, true); root.addView(status);
        TextView desc = text("B：把小布识别出的应用名称映射到你指定的应用。\nC：把自定义口令映射到你指定的应用。\n模块只修改小布的目标包名，不伪造解锁、不关闭系统认证。", 14, false);
        desc.setTextColor(0xff475467); root.addView(desc);
        addGap(root, 12);

        enableMaster = new CheckBox(this); enableMaster.setText("总开关：启用所有映射规则"); enableMaster.setChecked(prefs.getBoolean(KEY_ENABLE_MASTER, true)); root.addView(enableMaster);
        enableB = new CheckBox(this); enableB.setText("启用 B 模式：应用名称映射"); enableB.setChecked(prefs.getBoolean(KEY_ENABLE_B, true)); root.addView(enableB);
        enableC = new CheckBox(this); enableC.setText("启用 C 模式：自定义口令"); enableC.setChecked(prefs.getBoolean(KEY_ENABLE_C, true)); root.addView(enableC);
        allowLocked = new CheckBox(this); allowLocked.setText("锁屏时也应用映射（不绕过系统认证）"); allowLocked.setChecked(prefs.getBoolean(KEY_ALLOW_LOCKED, true)); root.addView(allowLocked);
        Button save = button("保存开关设置"); root.addView(save); save.setOnClickListener(v -> {
            prefs.edit().putBoolean(KEY_ENABLE_MASTER, enableMaster.isChecked()).putBoolean(KEY_ENABLE_B, enableB.isChecked()).putBoolean(KEY_ENABLE_C, enableC.isChecked()).putBoolean(KEY_ALLOW_LOCKED, allowLocked.isChecked()).apply();
            Toast.makeText(this, "设置已保存", Toast.LENGTH_SHORT).show();
        });

        addGap(root, 18);
        TextView rulesTitle = text("口令规则", 18, true); root.addView(rulesTitle);
        TextView ruleHint = text("别名可用逗号分隔。例如 B 模式填写“微信,WeChat”；C 模式填写“我的工具箱,工具箱”。匹配采用完整名称，避免误触发。", 13, false);
        ruleHint.setTextColor(0xff667085); root.addView(ruleHint);
        rulesBox = new LinearLayout(this); rulesBox.setOrientation(LinearLayout.VERTICAL); root.addView(rulesBox);
        Button add = button("＋ 添加映射规则"); root.addView(add); add.setOnClickListener(v -> showRuleEditor(-1));

        addGap(root, 18);
        TextView note = text("Hook 目标：com.heytap.speechassist\n入口：OpenAppOperation.tryLaunchApp(LaunchApp)\n配置桥接：只读 ContentProvider", 12, false);
        note.setTextColor(0xff98a2b3); root.addView(note);
    }

    private void refreshRules() {
        rulesBox.removeAllViews();
        JSONArray a = loadRules();
        if (a.length() == 0) {
            TextView empty = text("暂时没有规则。点击“添加映射规则”开始配置。", 14, false); empty.setTextColor(0xff667085); rulesBox.addView(empty); return;
        }
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i); if (o == null) continue;
            final int index = i;
            String mode = o.optString("mode", "B");
            String aliases = o.optString("aliases", "");
            String label = o.optString("appLabel", o.optString("packageName", ""));
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(12), dp(10), dp(12), dp(10));
            card.setBackgroundColor(0xfff1f4f8); LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.topMargin = dp(8); rulesBox.addView(card, cp);
            TextView line = text(("C".equals(mode) ? "C · 自定义口令" : "B · 应用名称") + "\n" + aliases + "\n→ " + label, 14, true); card.addView(line);
            CheckBox ruleEnabled = new CheckBox(this); ruleEnabled.setText("启用此规则"); ruleEnabled.setChecked(o.optBoolean("enabled", true)); card.addView(ruleEnabled);
            ruleEnabled.setOnCheckedChangeListener((button, checked) -> {
                JSONArray now = loadRules(); JSONObject item = now.optJSONObject(index);
                if (item == null) return;
                try {
                    item.put("enabled", checked); saveRules(now);
                    Toast.makeText(this, checked ? "规则已启用" : "规则已停用", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "保存规则状态失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
            LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); card.addView(actions);
            Button edit = smallButton("编辑"); actions.addView(edit); edit.setOnClickListener(v -> showRuleEditor(index));
            Button del = smallButton("删除"); actions.addView(del); del.setOnClickListener(v -> { JSONArray now = loadRules(); JSONArray out = new JSONArray(); for (int j=0;j<now.length();j++) if (j!=index) out.put(now.optJSONObject(j)); saveRules(out); refreshRules(); });
        }
    }

    private void showRuleEditor(int index) {
        JSONArray all = loadRules(); JSONObject old = index >= 0 ? all.optJSONObject(index) : null;
        LinearLayout form = new LinearLayout(this); form.setPadding(dp(16), dp(8), dp(16), dp(4)); form.setOrientation(LinearLayout.VERTICAL);
        Spinner mode = new Spinner(this); mode.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"B · 应用名称映射", "C · 自定义口令"}));
        if (old != null && "C".equals(old.optString("mode"))) mode.setSelection(1); form.addView(mode);
        EditText aliases = new EditText(this); aliases.setSingleLine(false); aliases.setMinLines(2); aliases.setHint("触发名称 / 口令，多个用逗号分隔"); aliases.setText(old == null ? "" : old.optString("aliases", "")); form.addView(aliases);
        EditText pkg = new EditText(this); pkg.setSingleLine(true); pkg.setHint("目标应用包名"); pkg.setText(old == null ? "" : old.optString("packageName", "")); form.addView(pkg);
        EditText label = new EditText(this); label.setSingleLine(true); label.setHint("应用显示名称（可选）"); label.setText(old == null ? "" : old.optString("appLabel", "")); form.addView(label);
        Button pick = smallButton("从已安装应用中选择"); form.addView(pick); pick.setOnClickListener(v -> chooseApp(pkg, label));
        new AlertDialog.Builder(this).setTitle(index < 0 ? "添加规则" : "编辑规则").setView(form)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", (d, w) -> {
                    String p = pkg.getText().toString().trim(); String a = aliases.getText().toString().trim();
                    if (p.isEmpty() || a.isEmpty()) { Toast.makeText(this, "包名和触发名称不能为空", Toast.LENGTH_LONG).show(); return; }
                    try {
                        JSONObject item = new JSONObject(); item.put("mode", mode.getSelectedItemPosition() == 1 ? "C" : "B"); item.put("aliases", a); item.put("packageName", p); item.put("appLabel", label.getText().toString().trim().isEmpty() ? p : label.getText().toString().trim()); item.put("enabled", old == null || old.optBoolean("enabled", true));
                        JSONArray out = new JSONArray(); for (int j=0;j<all.length();j++) if (j!=index) out.put(all.optJSONObject(j)); out.put(item); saveRules(out); refreshRules();
                    } catch (Exception e) { Toast.makeText(this, "保存失败：" + e.getMessage(), Toast.LENGTH_LONG).show(); }
                }).show();
    }

    private void chooseApp(EditText pkg, EditText label) {
        try {
            PackageManager pm = getPackageManager(); List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
            List<ApplicationInfo> launchable = new ArrayList<>();
            for (ApplicationInfo ai : apps) if (pm.getLaunchIntentForPackage(ai.packageName) != null && !ai.packageName.equals(getPackageName())) launchable.add(ai);
            Collections.sort(launchable, Comparator.comparing(ai -> pm.getApplicationLabel(ai).toString(), String.CASE_INSENSITIVE_ORDER));
            String[] names = new String[launchable.size()];
            for (int i=0;i<launchable.size();i++) names[i] = pm.getApplicationLabel(launchable.get(i)) + "  ·  " + launchable.get(i).packageName;
            new AlertDialog.Builder(this).setTitle("选择目标应用").setItems(names, (d, which) -> { ApplicationInfo ai = launchable.get(which); pkg.setText(ai.packageName); label.setText(pm.getApplicationLabel(ai)); }).show();
        } catch (Throwable t) { Toast.makeText(this, "读取应用列表失败：" + t.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    private JSONArray loadRules() { try { return new JSONArray(prefs.getString(KEY_RULES, "[]")); } catch (Exception e) { return new JSONArray(); } }
    private void saveRules(JSONArray a) { prefs.edit().putString(KEY_RULES, a.toString()).apply(); }
    private TextView text(String s, int sp, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(0xff17212f); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t; }
    private Button button(String s) { Button b = new Button(this); b.setText(s); return b; }
    private Button smallButton(String s) { Button b = new Button(this); b.setText(s); b.setTextSize(12); return b; }
    private void addGap(LinearLayout box, int dp) { View v = new View(this); box.addView(v, new LinearLayout.LayoutParams(1, dp(dp))); }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
