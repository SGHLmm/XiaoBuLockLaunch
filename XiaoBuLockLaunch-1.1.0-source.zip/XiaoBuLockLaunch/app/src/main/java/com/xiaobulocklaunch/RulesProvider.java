package com.xiaobulocklaunch;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;

/** Read-only bridge used by the hooked XiaoBu process to obtain module settings. */
public final class RulesProvider extends ContentProvider {
    public static final String AUTHORITY = "com.xiaobulocklaunch.rules";
    public static final Uri URI = Uri.parse("content://" + AUTHORITY);

    @Override public boolean onCreate() { return true; }

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        if (!"get_config".equals(method)) return Bundle.EMPTY;
        enforceCaller();
        var p = getContext().getSharedPreferences(MainActivity.PREFS, 0);
        Bundle out = new Bundle();
        out.putString("rules_json", p.getString(MainActivity.KEY_RULES, "[]"));
        out.putBoolean("enable_master", p.getBoolean(MainActivity.KEY_ENABLE_MASTER, true));
        out.putBoolean("enable_b", p.getBoolean(MainActivity.KEY_ENABLE_B, true));
        out.putBoolean("enable_c", p.getBoolean(MainActivity.KEY_ENABLE_C, true));
        out.putBoolean("allow_locked_mapping", p.getBoolean(MainActivity.KEY_ALLOW_LOCKED, true));
        return out;
    }

    private void enforceCaller() {
        int uid = Binder.getCallingUid();
        if (uid == android.os.Process.myUid()) return;
        String[] packages = getContext().getPackageManager().getPackagesForUid(uid);
        if (packages != null) {
            for (String name : packages) {
                if ("com.heytap.speechassist".equals(name)) return;
            }
        }
        throw new SecurityException("Caller is not XiaoBu Assistant");
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) { return null; }
    @Override public String getType(Uri uri) { return "vnd.android.cursor.item/vnd.com.xiaobulocklaunch.config"; }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException("read only"); }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { throw new UnsupportedOperationException("read only"); }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { throw new UnsupportedOperationException("read only"); }
}
