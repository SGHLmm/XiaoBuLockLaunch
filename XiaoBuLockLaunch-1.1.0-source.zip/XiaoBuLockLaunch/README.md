# XiaoBuLockLaunch（小布锁屏启动）

面向一加 13 PJZ110 / ColorOS 17 / 小布助手 `com.heytap.speechassist` 13.4.3 的 LSPosed 模块工程。

## 当前实现

- 仅注入 `com.heytap.speechassist`。
- Hook APK 中已核实的方法：
  `com.heytap.speechassist.skill.openapp.operation.OpenAppOperation#tryLaunchApp(com.heytap.speech.engine.protocol.directive.app.LaunchApp)`。
- 读取 `LaunchApp.getAppName()` / `getPackageName()`，按规则调用 `setPackageName()` / `setAppName()`。
- B 模式：应用名称/别名映射。
- C 模式：自定义口令别名映射。
- 总开关：一键暂停/恢复全部映射。
- 每条规则独立启用/停用，编辑规则时保留原启用状态。
- 通过只读 ContentProvider 将模块设置提供给小布进程；Provider 只允许 `com.heytap.speechassist` UID 读取。
- 锁屏时可选择是否应用映射，但不会伪造解锁成功、关闭 Keyguard、绕过密码/生物识别或修改系统安全策略。

## 重要兼容性边界

C 模式当前是在小布发出的 `LaunchApp` 指令中，以 `appName` 字段匹配自定义别名。只有当小布把用户说的自定义口令解析成 `LaunchApp` 指令，并把口令/目标名称放进 `appName` 时，当前 Hook 才能命中。如果小布没有产生该指令（例如将口令识别为闲聊或其他技能），单靠这个 Hook 无法强制把它变成启动应用命令；需要进一步定位语音文本/意图分发入口后再扩展。

锁屏映射只改变小布请求启动的目标应用。最终是否能在锁屏上显示目标 Activity，仍由小布原有 Keyguard 流程、Android 后台启动限制、目标应用安全策略和系统认证决定。此工程不承诺绕过这些限制。

## 1.1.0 更新

- 新增全局总开关；关闭后 Hook 不执行任何映射。
- 新增每条规则的独立启用/停用开关。
- 编辑规则时保留其原有启用状态。
- 新增 GitHub Actions 自动构建工作流，推送代码后可在 Actions 下载 Debug APK。

## 工程构建

1. 用 Android Studio 打开本目录。
2. 使用 JDK 17、Android SDK Platform 35、Gradle 8.9。
3. 同步 Gradle（需要网络下载 Android Gradle Plugin 和 Xposed API 82）。
4. 选择 `app` 的 `assembleDebug`，生成 `app/build/outputs/apk/debug/app-debug.apk`。

当前 ZIP 未包含 Gradle Wrapper JAR；可使用 Android Studio 导入并同步，或通过仓库内 GitHub Actions 工作流在线构建。此交付环境没有 Android SDK/Gradle，因此本次只交付源码工程，未声称已编译或实机验证 APK。

## 安装和启用

1. 安装编译得到的 APK。
2. 在 LSPosed 管理器中启用 XiaoBuLockLaunch。
3. 作用域只勾选“小布助手”（`com.heytap.speechassist`）。
4. 重启小布助手进程；如 Hook 未加载，再重启系统。
5. 打开模块设置，添加 B/C 规则并保存。
6. 先在已解锁状态测试；确认日志出现 `hooked OpenAppOperation.tryLaunchApp` 和 `remap:` 后，再测试锁屏场景。

## 规则示例

- B：模式选“应用名称映射”；别名填 `微信,WeChat`；目标选微信。
- C：模式选“自定义口令”；别名填 `我的工具箱,工具箱`；目标选你希望启动的应用。

别名以逗号、分号或换行分隔。匹配会去除空格、常见标点以及“打开/启动/请打开”等前缀，采用完整名称匹配，不做模糊包含匹配。

## 故障排查

- LSPosed 日志过滤：`XiaoBuLockLaunch`。
- 如果没有 `hooked...`：检查作用域是否包含 `com.heytap.speechassist`，以及当前小布版本是否仍为 13.4.3。
- 如果有 `hooked...` 但没有 `remap:`：说明该次指令没有进入 `OpenAppOperation.tryLaunchApp`，或 `LaunchApp.appName/packageName` 与配置别名不一致。
- 如果有 `remap:` 但锁屏没有显示应用：这是系统/小布原生 Keyguard 或后台 Activity 启动限制，不代表包名映射失败。
